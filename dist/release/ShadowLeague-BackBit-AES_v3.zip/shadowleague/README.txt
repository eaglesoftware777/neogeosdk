Shadow League -- BackBit Platinum (AES)

Copy the shadowleague folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
AES identifies the console-mode program header only.
It does not establish AES hardware compatibility or announce an AES cartridge.
The BackBit Platinum product is for MVS; use the MVS build on an MVS board.

  shadowleague.p1   3145728  a7e64d62
  shadowleague.s1    131072  636d9736
  shadowleague.m1    131072  ceabdb57
  shadowleague.v1   7979264  63c1b4e6
  shadowleague.c1   8388608  ac935b79
  shadowleague.c2   8388608  d65c95ab
