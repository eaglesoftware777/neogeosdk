Seven Wonders Puzzles -- BackBit Platinum (AES)

Copy the sevenwonders folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
AES identifies the console-mode program header only.
It does not establish AES hardware compatibility or announce an AES cartridge.
The BackBit Platinum product is for MVS; use the MVS build on an MVS board.

  sevenwonders.p1    524288  393ea64a
  sevenwonders.s1    131072  eb99e197
  sevenwonders.m1    131072  a8031d28
  sevenwonders.v1   3294208  afec46cd
  sevenwonders.c1   4194304  20efee4b
  sevenwonders.c2   4194304  2e56f9b5
