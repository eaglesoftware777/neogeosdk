Maiya: Super Nature Girl -- BackBit Platinum (MVS)

Copy the maiya folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.

  maiya.p1    524288  9c3698fb
  maiya.s1    131072  5c7951e1
  maiya.m1    131072  ce7717bd
  maiya.v1   7973632  127b89b4
  maiya.c1   4194304  5fa779f8
  maiya.c2   4194304  3af3dc8f
