Maiya: Super Nature Girl -- BackBit Platinum (MVS)

Copy the maiya folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  maiya.p1    524288  dea0d97d
  maiya.s1    131072  07999a92
  maiya.m1    131072  0f629a39
  maiya.v1   7973888  da7df961
  maiya.c1   4194304  131fc3fc
  maiya.c2   4194304  55a6ddcf
