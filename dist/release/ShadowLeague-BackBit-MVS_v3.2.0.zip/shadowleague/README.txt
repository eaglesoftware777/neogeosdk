Shadow League Fighting -- BackBit Platinum (MVS)

Copy the shadowleague folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  shadowleague.p1   3145728  664a2881
  shadowleague.s1    131072  9dc036cc
  shadowleague.m1    131072  d33dbcbd
  shadowleague.v1   7984384  0e34c91f
  shadowleague.c1   8388608  dbb8854a
  shadowleague.c2   8388608  e13b5303
