Maiya & Luna -- BackBit Platinum (AES)

Copy the maiyaluna folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
AES identifies the console-mode program header only.
It does not establish AES hardware compatibility or announce an AES cartridge.
The BackBit Platinum product is for MVS; use the MVS build on an MVS board.

  maiyaluna.p1    524288  f0e542a9
  maiyaluna.s1    131072  74a73a67
  maiyaluna.m1    131072  f8436258
  maiyaluna.v1   7783424  0518d9fc
  maiyaluna.c1   4194304  cd2c43bb
  maiyaluna.c2   4194304  60b12724
