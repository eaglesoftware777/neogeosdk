Shadow League Fighting -- BackBit Platinum (MVS)

Copy the shadowleague folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.

  shadowleague.p1    524288  886561bd
  shadowleague.s1    131072  0e78a88f
  shadowleague.m1    131072  6738f78a
  shadowleague.v1   2097152  1753d05d
  shadowleague.c1   4194304  e43c5e4b
  shadowleague.c2   4194304  498fb2dc
