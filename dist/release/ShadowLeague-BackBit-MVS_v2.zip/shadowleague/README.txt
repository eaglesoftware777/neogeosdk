Shadow League Fighting -- BackBit Platinum (MVS)

Copy the shadowleague folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.

  shadowleague.p1    524288  9c4ad121
  shadowleague.s1    131072  f0e7a314
  shadowleague.m1    131072  6738f78a
  shadowleague.v1   2097152  1753d05d
  shadowleague.c1   4194304  ff6867e6
  shadowleague.c2   4194304  ad227d43
