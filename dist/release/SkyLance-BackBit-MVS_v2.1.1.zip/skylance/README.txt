Sky Lance -- BackBit Platinum (MVS)

Copy the skylance folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  skylance.p1    524288  37407333
  skylance.s1    131072  bd69c9ff
  skylance.m1    131072  a90b6479
  skylance.v1   4546304  897c1fbc
  skylance.c1   4194304  c1a3ebfd
  skylance.c2   4194304  75a51449
