Maiya & Luna -- BackBit Platinum (MVS)

Copy the maiyaluna folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  maiyaluna.p1    524288  f9fdaa99
  maiyaluna.s1    131072  74a73a67
  maiyaluna.m1    131072  f8436258
  maiyaluna.v1   7783424  0518d9fc
  maiyaluna.c1   4194304  cd2c43bb
  maiyaluna.c2   4194304  60b12724
