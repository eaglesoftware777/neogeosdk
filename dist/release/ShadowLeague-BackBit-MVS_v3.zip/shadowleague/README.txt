Shadow League -- BackBit Platinum (MVS)

Copy the shadowleague folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  shadowleague.p1   3145728  3f53b8e5
  shadowleague.s1    131072  636d9736
  shadowleague.m1    131072  ceabdb57
  shadowleague.v1   7979264  63c1b4e6
  shadowleague.c1   8388608  e9b1d686
  shadowleague.c2   8388608  e03418d8
