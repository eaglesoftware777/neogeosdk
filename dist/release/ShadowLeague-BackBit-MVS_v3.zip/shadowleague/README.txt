Shadow League Fighting -- BackBit Platinum (MVS)

Copy the shadowleague folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  shadowleague.p1   3145728  20a6ea2d
  shadowleague.s1    131072  636d9736
  shadowleague.m1    131072  ceabdb57
  shadowleague.v1   7979264  63c1b4e6
  shadowleague.c1   8388608  a8420eed
  shadowleague.c2   8388608  efd2b313
