Shadow League Fighting -- BackBit Platinum (MVS)

Copy the shadowleague folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  shadowleague.p1   3145728  096d0f29
  shadowleague.s1    131072  b53dfd32
  shadowleague.m1    131072  ff00178f
  shadowleague.v1  10121472  a58dbef4
  shadowleague.c1  16777216  ae6501d5
  shadowleague.c2  16777216  bb93cb6c
