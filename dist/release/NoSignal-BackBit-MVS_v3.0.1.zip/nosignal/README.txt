No Signal Z Alpha -- BackBit Platinum (MVS)

Copy the nosignal folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  nosignal.p1    524288  1d6039d6
  nosignal.s1    131072  9f97dd8c
  nosignal.m1    131072  2a611d71
  nosignal.v1   6015232  14b1eaa1
  nosignal.c1   4194304  91d38b2c
  nosignal.c2   4194304  1e73b533
