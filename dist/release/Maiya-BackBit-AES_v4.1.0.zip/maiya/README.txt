Maiya: Super Nature Girl -- BackBit Platinum (AES)

Copy the maiya folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
AES identifies the console-mode program header only.
It does not establish AES hardware compatibility or announce an AES cartridge.
The BackBit Platinum product is for MVS; use the MVS build on an MVS board.

  maiya.p1    524288  d7b8314d
  maiya.s1    131072  07999a92
  maiya.m1    131072  0f629a39
  maiya.v1   7973888  da7df961
  maiya.c1   4194304  131fc3fc
  maiya.c2   4194304  55a6ddcf
