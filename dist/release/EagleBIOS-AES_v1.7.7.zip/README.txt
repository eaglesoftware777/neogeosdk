EagleBIOS for the AES (NeoGeoSDK v1.7.7)

An original system ROM for the Neo Geo AES console, built from source in the
NeoGeoSDK (bios/). No vendor code, data or font is copied.

  roms/aes/neo-epo.bin   the 68000 firmware (AES, board id 0002)
  roms/aes/000-lo.lo     the LSPC vertical shrink table

In MAME, put both files in roms/aes (or in roms/aes.zip) and start a game with

  mame aes -bios asia -cart1 <game>

EagleBIOS stands in for the system ROM: checksum warnings for it are expected.

SHA-256
  7eec66f43b306c00bd66e25f57cf9480d3dc792c413a9cbe98425a56ea6274b7  neo-epo.bin
  7eff4efa47f1560af2eca65a846b60567f1bd84bfce63ff8987c714ed20255c7  000-lo.lo

MIT License: see LICENSE.
