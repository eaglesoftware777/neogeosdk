EagleBIOS for the MVS (NeoGeoSDK v1.7.7)

An original system ROM set for Neo Geo MVS arcade boards, built from source in
the NeoGeoSDK (bios/). No vendor code, data or font is copied.

  roms/neogeo/sp-s2.sp1   the 68000 firmware (MVS, board id 8002)
  roms/neogeo/sm1.sm1     the Z80 system sound program
  roms/neogeo/sfix.sfix   the system text font
  roms/neogeo/000-lo.lo   the LSPC vertical shrink table

In MAME, put the four files in roms/neogeo (or in roms/neogeo.zip) and start a
game with

  mame neogeo -bios euro -cart1 <game>

EagleBIOS stands in for the system ROM: checksum warnings for it are expected.

SHA-256
  aae26373b3e393782bd3aaf58c6de16df3f52b9142d28838be28692d1621d21d  sp-s2.sp1
  b16c4f69d01853bc5c074fe1be41e028ec950ce8cc3cb88abd385a169fdb4234  sm1.sm1
  feca1c2515473c34be89b76b45f01ec4e55a0325fe06c732b357982d047e0b96  sfix.sfix
  7eff4efa47f1560af2eca65a846b60567f1bd84bfce63ff8987c714ed20255c7  000-lo.lo

MIT License: see LICENSE.
