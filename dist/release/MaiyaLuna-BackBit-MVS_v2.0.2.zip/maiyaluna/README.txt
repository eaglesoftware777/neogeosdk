Maiya & Luna -- BackBit Platinum (MVS)

Copy the maiyaluna folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  maiyaluna.p1    524288  15d8fdd3
  maiyaluna.s1    131072  74a73a67
  maiyaluna.m1    131072  b291e256
  maiyaluna.v1   7783424  0518d9fc
  maiyaluna.c1   4194304  b73a67ac
  maiyaluna.c2   4194304  9707b70a
