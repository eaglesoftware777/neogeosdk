Century XI: Road to 2030 -- BackBit Platinum (AES)

Copy the centuryxi folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
AES identifies the console-mode program header only.
It does not establish AES hardware compatibility or announce an AES cartridge.
The BackBit Platinum product is for MVS; use the MVS build on an MVS board.

  centuryxi.p1    524288  e3716e70
  centuryxi.s1    131072  fc83bf13
  centuryxi.m1    131072  4a077d51
  centuryxi.v1   7585536  18ecd70b
  centuryxi.c1   4194304  6f2011b2
  centuryxi.c2   4194304  907bc964
