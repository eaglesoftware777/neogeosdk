Mahjong Demo -- BackBit Platinum (AES)

Copy the mahjong_demo folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
AES identifies the console-mode program header only.
It does not establish AES hardware compatibility or announce an AES cartridge.
The BackBit Platinum product is for MVS; use the MVS build on an MVS board.

  mahjong_demo.p1    524288  c197be3f
  mahjong_demo.s1    131072  fa8680fe
  mahjong_demo.m1    131072  a227f905
  mahjong_demo.v1   2097152  f04d0f8d
  mahjong_demo.c1   4194304  96cd3e55
  mahjong_demo.c2   4194304  f9d40dc0
