Maiya: Super Nature Girl -- Darksoft Neo Geo Multi (AES)

Copy this folder to a game folder on the Darksoft Multi SD card.
No system BIOS is included: the Multi uses the board's.

  prom    P ROM
  srom    S (FIX) ROM
  m1rom   Z80 M ROM
  vroma0  V ROM, padded with $FF to a power of two
  crom0   C1/C2 in Darksoft two-byte pair interleave
  fpga    ASCII "10"

Built by tools/pack_darksoft.py from the cartridge's own ROMs; crom0 is
checked to come back out as C1 and C2 byte for byte (MANIFEST.json).
