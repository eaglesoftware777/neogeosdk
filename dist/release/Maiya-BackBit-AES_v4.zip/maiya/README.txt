Maiya: Super Nature Girl -- BackBit Platinum (AES)

Copy the maiya folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.

  maiya.p1    524288  56fa6261
  maiya.s1    131072  5c7951e1
  maiya.m1    131072  ce7717bd
  maiya.v1   7973632  127b89b4
  maiya.c1   4194304  1ec8e364
  maiya.c2   4194304  f324e7d4
