Seven Wonders Puzzles -- BackBit Platinum (MVS)

Copy the sevenwonders folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  sevenwonders.p1    524288  30264e7a
  sevenwonders.s1    131072  eb99e197
  sevenwonders.m1    131072  a8031d28
  sevenwonders.v1   3294208  afec46cd
  sevenwonders.c1   4194304  20efee4b
  sevenwonders.c2   4194304  2e56f9b5
