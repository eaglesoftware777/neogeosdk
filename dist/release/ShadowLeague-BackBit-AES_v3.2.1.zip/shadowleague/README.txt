Shadow League Fighting -- BackBit Platinum (AES)

Copy the shadowleague folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
AES identifies the console-mode program header only.
It does not establish AES hardware compatibility or announce an AES cartridge.
The BackBit Platinum product is for MVS; use the MVS build on an MVS board.

  shadowleague.p1   3145728  5daabaaa
  shadowleague.s1    131072  9dc036cc
  shadowleague.m1    131072  60928aa8
  shadowleague.v1   7984384  c4f30a19
  shadowleague.c1   8388608  dbb8854a
  shadowleague.c2   8388608  e13b5303
