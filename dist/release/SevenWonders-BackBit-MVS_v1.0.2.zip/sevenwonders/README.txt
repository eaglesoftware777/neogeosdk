Seven Wonders Puzzles -- BackBit Platinum (MVS)

Copy the sevenwonders folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  sevenwonders.p1    524288  940645d5
  sevenwonders.s1    131072  ba1031c2
  sevenwonders.m1    131072  d8b445f0
  sevenwonders.v1   3796992  565b83c5
  sevenwonders.c1   4194304  d77a28cd
  sevenwonders.c2   4194304  274b42d0
