MAIYA: SUPER NATURE GIRL  --  Eagle Software, 2026
===================================================

!! WORK IN PROGRESS !!  This is a preview build, not a finished game.
Expect rough edges, placeholder art in places, and balance that is still
being tuned. Thank you for playing and testing it!

THE STORY (a few hints)
-----------------------
Lord Smoggar and his guardians have poisoned twelve valleys: forests cut,
falls choked with sludge, coasts drowned in plastic, skies full of smog.
Their machines -- saw bots, drill bots, torch bots, smoke stacks -- and
the trash beasts do the dirty work for them.
Maiya (or Luna) sets out to heal each valley: free the captives held in
chests, find the Sun Key, and pass through the ancient gate at the end of
the road to face its guardian. Each healed valley blooms again, and the
elder has a word for the road ahead. Sunboy waits in his crystal...
Look for hidden vaults: spirit orbs there teach new Secret Arts.

CONTROLS
--------
A  jump (Up + A in the air: a second jump while a sky lily lasts;
   kneel, then Up + A: the high leap)
B  thorn / whip up close (hold: run)
C  dash
D  Secret Art (uses a rose charge)
Forward, Down, Down-Forward + B : Rising Bloom
Down, Forward + B               : Rose Blossom Surge

WHAT'S IN THIS PACKAGE
----------------------
Maiya-WIP-EagleBIOS.zip   the game's ROMs plus EagleBIOS, the free
                          open-source replacement system firmware, for MAME:
                            mame aes -rompath roms -hashpath hash -bios asia -cart1 maiya
                          (checksum warnings for the replacement firmware
                          are expected)
Maiya-WIP-AES-NeoGeoBIOS.zip  the game's ROMs with the original Asia AES
                          system BIOS and lookup ROM, for MAME:
                            mame aes -rompath roms -hashpath hash -bios asia -cart1 maiya
Maiya-WIP-NeoSD.neo       original preview image, restored byte-for-byte
                          from commit 3e5e68a.
Maiya-WIP-NeoSD_AES.neo   AES console build with the startup fix.
Maiya-WIP-NeoSD_MVS.neo   MVS arcade build.
                          Copy the appropriate image to the NeoSD card.

The .neo files contain cartridge data only, with no bundled system BIOS.
The AES packages use the AES build with the BIOS eye-catcher disabled;
the game's own logo appears in the attract sequence.
Physical NeoSD hardware compatibility still needs hardware testing.

USA AND EUROPE
--------------
Maiya-WIP-AES-USA.zip and Maiya-WIP-AES-Europe.zip include UniBIOS 4.0.
Run the command in RUN.txt, then hold A+B+C during the UniBIOS splash
to enter setup. Select USA or Europe as named by the package, and Console
(AES) mode. These ZIPs require this region selection on first use.
MAME's stock AES BIOS choices are Asia and Japan, with no separate stock
USA or Europe option. The regional packages use unmodified UniBIOS.

All three .neo images use the system's installed BIOS and contain no
EagleBIOS or other BIOS. The system BIOS determines the region.
All BIOS versions and physical flash carts have not been tested.

ENGINE WORK IN THIS BUILD
-------------------------
- Eagle Software NeoGeoSDK 2D engine: camera, physics, sprite groups,
  palette effects (valleys that brighten as they heal, colour-shaking arts)
- painted landmarks and creatures, particle showers, formation flight
- synthesized voices for both heroines, ADPCM music and effects
- separate cartridge builds for arcade (MVS) and console (AES)
Coming next: a platform layer for MVS / AES / Neo Geo CD, a locked frame
rate, raster effects (rippling water), more polish everywhere.
