Sky Lance -- BackBit Platinum (AES)

Copy the skylance folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
AES identifies the console-mode program header only.
It does not establish AES hardware compatibility or announce an AES cartridge.
The BackBit Platinum product is for MVS; use the MVS build on an MVS board.

  skylance.p1    524288  3e589b03
  skylance.s1    131072  bd69c9ff
  skylance.m1    131072  a90b6479
  skylance.v1   4546304  897c1fbc
  skylance.c1   4194304  c1a3ebfd
  skylance.c2   4194304  75a51449
