Sky Lance -- BackBit Platinum (AES)

Copy the skylance folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.

  skylance.p1    524288  fabdbbc5
  skylance.s1    131072  bd69c9ff
  skylance.m1    131072  cb88d068
  skylance.v1   4546304  897c1fbc
  skylance.c1   4194304  e80e7df9
  skylance.c2   4194304  0668da32
