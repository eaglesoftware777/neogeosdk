EagleBIOS-CD for the Neo Geo CDZ (NeoGeoSDK v1.7.7, experimental)

An original CD system ROM, built from source in the NeoGeoSDK (bios/cd).
No stock firmware, artwork, sound driver or patches are included.

  roms/neocdz/neocd.bin   the firmware for MAME (word-reversed storage)
  eagle_cd_cdz.rom        the same firmware in CPU byte order (for tools)

Do not interchange the two formats. In MAME, put neocd.bin in roms/neocdz and
supply your own lawful 000-lo.lo data there too; then run a CD game with

  mame neocdz -cdrom <game>.cue

Tested in emulation only: Maiya and Sky Lance boot from disc with controls,
sound effects and CD audio. Saves, media changes, the front- and top-loader
models and real hardware are not verified. Do not flash it as finished
hardware firmware. It is the same firmware as
EagleBIOS-CD-CDZ_v1.7.7-experimental-r2.zip, rebuilt from the current source.

SHA-256
  22f259d1bee3a40a1cf404a564fea66a037376aeb57225bcc0f2dd586b070e3a  neocd.bin
  b14c6383ec88c38b51c8f48f85786162e0e4e67bfff2841043cc4dfbe702dc85  eagle_cd_cdz.rom

MIT License: see LICENSE.
