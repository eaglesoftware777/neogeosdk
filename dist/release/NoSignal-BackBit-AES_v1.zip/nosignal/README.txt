No Signal Z Alpha -- BackBit Platinum (AES)

Copy the nosignal folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
AES identifies the console-mode program header only.
It does not establish AES hardware compatibility or announce an AES cartridge.
The BackBit Platinum product is for MVS; use the MVS build on an MVS board.

  nosignal.p1    524288  359167dc
  nosignal.s1    131072  fb90dfcc
  nosignal.m1    131072  f9cc515e
  nosignal.v1   6019840  d57dbcf8
  nosignal.c1   4194304  814b6a0d
  nosignal.c2   4194304  3f67cee5
