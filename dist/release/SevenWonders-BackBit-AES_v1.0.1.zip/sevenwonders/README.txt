Seven Wonders Puzzles -- BackBit Platinum (AES)

Copy the sevenwonders folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
AES identifies the console-mode program header only.
It does not establish AES hardware compatibility or announce an AES cartridge.
The BackBit Platinum product is for MVS; use the MVS build on an MVS board.

  sevenwonders.p1    524288  58d352de
  sevenwonders.s1    131072  ba1031c2
  sevenwonders.m1    131072  c965f1bf
  sevenwonders.v1   3796992  565b83c5
  sevenwonders.c1   4194304  d77a28cd
  sevenwonders.c2   4194304  274b42d0
