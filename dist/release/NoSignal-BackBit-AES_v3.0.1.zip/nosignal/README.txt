No Signal Z Alpha -- BackBit Platinum (AES)

Copy the nosignal folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
AES identifies the console-mode program header only.
It does not establish AES hardware compatibility or announce an AES cartridge.
The BackBit Platinum product is for MVS; use the MVS build on an MVS board.

  nosignal.p1    524288  1478d1e6
  nosignal.s1    131072  9f97dd8c
  nosignal.m1    131072  2a611d71
  nosignal.v1   6015232  14b1eaa1
  nosignal.c1   4194304  91d38b2c
  nosignal.c2   4194304  1e73b533
