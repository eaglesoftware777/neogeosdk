Shadow League Fighting -- BackBit Platinum (AES)

Copy the shadowleague folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
AES identifies the console-mode program header only.
It does not establish AES hardware compatibility or announce an AES cartridge.
The BackBit Platinum product is for MVS; use the MVS build on an MVS board.

  shadowleague.p1   3145728  10ed111d
  shadowleague.s1    131072  b53dfd32
  shadowleague.m1    131072  ff00178f
  shadowleague.v1  10121472  a58dbef4
  shadowleague.c1  16777216  ae6501d5
  shadowleague.c2  16777216  bb93cb6c
