Century XI: Road to 2030 -- BackBit Platinum (MVS)

Copy the centuryxi folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  centuryxi.p1    524288  123d1197
  centuryxi.s1    131072  fc83bf13
  centuryxi.m1    131072  4a077d51
  centuryxi.v1   7585536  18ecd70b
  centuryxi.c1   4194304  6f2011b2
  centuryxi.c2   4194304  907bc964
