No Signal Z Alpha -- BackBit Platinum (MVS)

Copy the nosignal folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  nosignal.p1    524288  814e8d63
  nosignal.s1    131072  fb90dfcc
  nosignal.m1    131072  f9cc515e
  nosignal.v1   6019840  d57dbcf8
  nosignal.c1   4194304  fb971306
  nosignal.c2   4194304  fba2415a
