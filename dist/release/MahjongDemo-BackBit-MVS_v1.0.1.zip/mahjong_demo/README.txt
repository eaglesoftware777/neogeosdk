Mahjong Demo -- BackBit Platinum (MVS)

Copy the mahjong_demo folder to the BackBit Platinum's microSD card.
No system BIOS is included: the BackBit uses the board's.
This is the MVS program build for the BackBit Platinum MVS cartridge.

  mahjong_demo.p1    524288  4408262b
  mahjong_demo.s1    131072  fa8680fe
  mahjong_demo.m1    131072  7ff60c6e
  mahjong_demo.v1   2097152  f04d0f8d
  mahjong_demo.c1   4194304  96cd3e55
  mahjong_demo.c2   4194304  f9d40dc0
